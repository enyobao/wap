#animateheader

This plugin will animate headers during transitions. Simply include the script to enable header animations during panel transitions.

